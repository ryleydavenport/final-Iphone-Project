//
//  BackgroundMusic.swift
//  Group14
//
//  Created by Taelor Mcmillan on 2018-03-26.
//  Copyright © 2018 Taelor Mcmillan. All rights reserved.
//

import UIKit
import AVFoundation
class BackgroundMusic {
    static let sharedHelper = BackgroundMusic ()
    var audioPlayer: AVAudioPlayer!
    
    func playbackgroundMusic(){
        let url = Bundle.main.url(forResource: "background.mp3" , withExtension: nil)
        do{
            try audioPlayer = AVAudioPlayer(contentsOf: url!)
        }
        catch{
            print("Could not find audio player")
        }
        audioPlayer.numberOfLoops = -1
        audioPlayer.prepareToPlay()
        audioPlayer.play()
    }
    func stopBackgroundMusic(){
        audioPlayer.stop()
    }
}
