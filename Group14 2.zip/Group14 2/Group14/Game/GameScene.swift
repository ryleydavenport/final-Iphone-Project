//
//  GameScene.swift
//  Group14
//
//  Created by Taelor Mcmillan on 2018-03-25.
//  Copyright © 2018 Taelor Mcmillan. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene,UITextFieldDelegate {
    
    let apple = SKSpriteNode(imageNamed: "apple")
    let apple2 = SKSpriteNode(imageNamed: "apple")
    let apple3 = SKSpriteNode(imageNamed: "apple")
    let apple4 = SKSpriteNode(imageNamed: "apple")
    let apple5 = SKSpriteNode(imageNamed: "apple")
    let bannana = SKSpriteNode(imageNamed: "bannana")
    let bannana2 = SKSpriteNode(imageNamed: "bannana")
    let bannana3 = SKSpriteNode(imageNamed: "bannana")
    let bannana4 = SKSpriteNode(imageNamed: "bannana")
    let orange = SKSpriteNode(imageNamed: "orange")
    let orange2 = SKSpriteNode(imageNamed: "orange")
    let plus = SKLabelNode(text: "+")
    let plus2 = SKLabelNode(text: "+")
    let plus3 = SKLabelNode(text: "+")
    let plus4 = SKLabelNode(text: "+")
    let plus5 = SKLabelNode(text: "+")
    let plus6 = SKLabelNode(text: "+")
    let equals = SKLabelNode(text: "=")
    let equals2 = SKLabelNode(text: "=")
    let equals3 = SKLabelNode(text: "=")
    let equals4 = SKLabelNode(text: "=")
    let minus = SKLabelNode(text: "-")
    let answer = SKLabelNode(text: "30")
    let answer2 = SKLabelNode(text: "18")
    let answer3 = SKLabelNode(text: "2")
    let question = SKLabelNode(text: "??")
    let answer4 = SKLabelNode(text: "Answer: ")
    
    override func didMove(to view: SKView) {
        let textfield = UITextView(frame: CGRect(x: size.width/2 - 175, y: size.height/2 - 160, width: 100, height: 30))
        print(size.width)
        print(size.height)
        apple.position = CGPoint(x: size.width/2 - 700, y: size.height/2 - 200)
        apple.name = "apple"
        apple.setScale(0.5)
        addChild(apple)
        
        plus.position = CGPoint(x: size.width/2 - 600, y: size.height/2 - 225)
        plus.fontSize = 100
        plus.name = "times"
        addChild(plus)
        
        apple2.position = CGPoint(x: size.width/2 - 500, y: size.height/2 - 200)
        apple2.name = "apple2"
        apple2.setScale(0.5)
        addChild(apple2)
        
        plus2.position = CGPoint(x: size.width/2 - 400, y: size.height/2 - 225)
        plus2.fontSize = 100
        plus2.name = "plus2"
        addChild(plus2)
        
        apple3.position = CGPoint(x: size.width/2 - 300, y: size.height/2 - 200)
        apple3.name = "apple3"
        apple3.setScale(0.5)
        addChild(apple3)
        
        equals.position = CGPoint(x: size.width/2 - 200, y: size.height/2 - 225)
        equals.fontSize = 100
        equals.name = "equals"
        addChild(equals)
        
        answer.position = CGPoint(x: size.width/2 - 100, y: size.height/2 - 225)
        answer.fontSize = 100
        answer.name = "answer"
        addChild(answer)
        
        apple4.position = CGPoint(x: size.width/2 - 700, y: size.height/2 - 400)
        apple4.name = "apple4"
        apple4.setScale(0.5)
        addChild(apple4)
        
        plus3.position = CGPoint(x: size.width/2 - 600, y: size.height/2 - 425)
        plus3.fontSize = 100
        plus3.name = "plus3"
        addChild(plus3)
        
        bannana.position = CGPoint(x: size.width/2 - 500, y: size.height/2 - 400)
        bannana.name = "bannana"
        bannana.setScale(0.5)
        addChild(bannana)
        
        plus4.position = CGPoint(x: size.width/2 - 400, y: size.height/2 - 425)
        plus4.fontSize = 100
        plus4.name = "plus4"
        addChild(plus4)
        
        bannana2.position = CGPoint(x: size.width/2 - 300, y: size.height/2 - 400)
        bannana2.name = "bannana2"
        bannana2.setScale(0.5)
        addChild(bannana2)
        
        equals2.position = CGPoint(x: size.width/2 - 200, y: size.height/2 - 425)
        equals2.fontSize = 100
        equals2.name = "equals2"
        addChild(equals2)
        
        answer2.position = CGPoint(x: size.width/2 - 100, y: size.height/2 - 425)
        answer2.fontSize = 100
        answer2.name = "answer2"
        addChild(answer2)
        
        bannana3.position = CGPoint(x: size.width/2 - 600, y: size.height/2 - 600)
        bannana3.name = "bannana3"
        bannana3.setScale(0.5)
        addChild(bannana3)
        
        minus.position = CGPoint(x: size.width/2 - 500, y: size.height/2 - 625)
        minus.fontSize = 100
        minus.name = "minus"
        addChild(minus)
        
        orange.position = CGPoint(x: size.width/2 - 400, y: size.height/2 - 600)
        orange.name = "orange"
        orange.setScale(0.5)
        addChild(orange)
        
        equals3.position = CGPoint(x: size.width/2 - 300, y: size.height/2 - 625)
        equals3.fontSize = 100
        equals3.name = "equals3"
        addChild(equals3)
        
        answer3.position = CGPoint(x: size.width/2 - 200, y: size.height/2 - 625)
        answer3.fontSize = 100
        answer3.name = "answer3"
        addChild(answer3)
        
        orange2.position = CGPoint(x: size.width/2 - 700, y: size.height/2 - 800)
        orange2.name = "orange2"
        orange2.setScale(0.5)
        addChild(orange2)
        
        plus5.position = CGPoint(x: size.width/2 - 600, y: size.height/2 - 825)
        plus5.fontSize = 100
        plus5.name = "plus5"
        addChild(plus5)
        
        apple5.position = CGPoint(x: size.width/2 - 500, y: size.height/2 - 800)
        apple5.name = "apple5"
        apple5.setScale(0.5)
        addChild(apple5)
        
        plus6.position = CGPoint(x: size.width/2 - 400, y: size.height/2 - 825)
        plus6.fontSize = 100
        plus6.name = "plus6"
        addChild(plus6)
        
        bannana4.position = CGPoint(x: size.width/2 - 300, y: size.height/2 - 800)
        bannana4.name = "bannana4"
        bannana4.setScale(0.5)
        addChild(bannana4)
        
        equals4.position = CGPoint(x: size.width/2 - 200, y: size.height/2 - 825)
        equals4.fontSize = 100
        equals4.name = "equals4"
        addChild(equals4)
        
        question.position = CGPoint(x: size.width/2 - 100, y: size.height/2 - 825)
        question.fontSize = 100
        question.name = "question"
        addChild(question)
        
        answer4.position = CGPoint(x: size.width/2 - 500, y: size.height/2 - 1000)
        answer4.fontSize = 50
        answer4.name = "answer4"
        addChild(answer4)
        
        view.addSubview(textfield)
    }
   
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Populates the SKLabelNode
        textField.resignFirstResponder()
        let useranswer = textField.text
        if (useranswer == "16"){
            print("you win!")
            //update high score, and segue to next game
        }
        else{
            textField.text = "Wrong!"
            textField.textColor = UIColor.red
        }
        // Hides the keyboard
        
        
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        let useranswer = textField.text
        if (useranswer == "16"){
            print("you win!")
            //update high score, and segue to next game
        }
        else{
            textField.text = "Wrong!"
            textField.textColor = UIColor.red
        }
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
   
    
}
