//
//  CreateUserViewController.swift
//  Group14
//
//  Created by Taelor Mcmillan on 2018-03-25.
//  Copyright © 2018 Taelor Mcmillan. All rights reserved.
//

import UIKit

class CreateUserViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {


    @IBOutlet weak var ImageViewer: UIImageView!
    
    @IBOutlet weak var ContinueButton: UIButton!
    @IBAction func ContinueButton(_ sender: Any) {
        SharingUserArray.sharedUser.userArray?.users.append(User(userimage: ImageViewer.image, userName: Nametext.text!, highScore: "0")!)
        SharingUserArray.sharedUser.userArray?.current = (SharingUserArray.sharedUser.userArray?.users.count)! - 1
        SharingUserArray.sharedUser.saveDeck()
        
        performSegue(withIdentifier: "MainMenuSegue2", sender: self)
    }
    @IBOutlet weak var Nametext: UITextField!
    
    @IBAction func SelectImage(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        self.present(imagePickerController, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let images = info[UIImagePickerControllerOriginalImage] as! UIImage
        ImageViewer.image = images
        picker.dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        Nametext.delegate = self
        ContinueButton.isEnabled = false

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if (Nametext.text != "") {
            ContinueButton.isEnabled = true
        }
        else{
            ContinueButton.isEnabled = false
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
