//
//  MainMenuViewController.swift
//  Group14
//
//  Created by Taelor Mcmillan on 2018-03-25.
//  Copyright © 2018 Taelor Mcmillan. All rights reserved.
//

import UIKit

class MainMenuViewController: UIViewController {

    @IBOutlet weak var currentUser: UILabel!
    @IBOutlet weak var highscoreLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currentUser.text = SharingUserArray.sharedUser.userArray?.users[(SharingUserArray.sharedUser.userArray?.current)!].userName
        highscoreLabel.text = SharingUserArray.sharedUser.userArray?.users[(SharingUserArray.sharedUser.userArray?.current)!].highScore
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func play(_ sender: Any) {
        performSegue(withIdentifier: "ShakeGame", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
