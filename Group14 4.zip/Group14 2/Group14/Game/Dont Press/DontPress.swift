//
//  DontPress.swift
//  Group14
//
//  Created by Taelor Mcmillan on 2018-03-30.
//  Copyright © 2018 Taelor Mcmillan. All rights reserved.
//

import UIKit
import SpriteKit
class DontPress: SKScene {
    override func didMove(to view: SKView) {
    
        let redButtonNode = SKSpriteNode(imageNamed: "redButton")
        redButtonNode.name = "red"
        redButtonNode.size = CGSize(width: self.size.width/4, height: self.size.height/4)
        redButtonNode.position = CGPoint (x: self.size.width/2  , y: self.size.height/2)
        self.addChild(redButtonNode)
        
        let greenButtonNode = SKSpriteNode(imageNamed: "greenButton")
        greenButtonNode.name = "green"
        greenButtonNode.size = CGSize(width: 10, height: 10)
        greenButtonNode.position = CGPoint(x: 100, y: 100  )
        self.addChild(greenButtonNode)
        
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: self)
        let touchedNode = self.atPoint(touchLocation)
        //checks to seee if any of the labels are touched
        if(touchedNode.name == "red"){
            print ("You Lose")
            
        }
        if(touchedNode.name == "green"){
            print ("You Win")
            
        }
        

        
    }
}
