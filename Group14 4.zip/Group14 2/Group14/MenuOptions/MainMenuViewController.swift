//
//  MainMenuViewController.swift
//  Group14
//
//  Created by Taelor Mcmillan on 2018-03-25.
//  Copyright © 2018 Taelor Mcmillan. All rights reserved.
//

import UIKit

class MainMenuViewController: UIViewController {

    @IBOutlet weak var currentUser: UILabel!
    @IBOutlet weak var highscoreLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //have to declare how many levels there are then make the if statements in the play button
        
        GlobalVar.sharedHelper.played_level = ["mathGame","DontPress","ShakeGame"]
        GlobalVar.sharedHelper.current_score = 0
        currentUser.text = SharingUserArray.sharedUser.userArray?.users[(SharingUserArray.sharedUser.userArray?.current)!].userName
        highscoreLabel.text = SharingUserArray.sharedUser.userArray?.users[(SharingUserArray.sharedUser.userArray?.current)!].highScore
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        //have to copy  the declare from didLoad to here as well
        GlobalVar.sharedHelper.played_level = ["mathGame","DontPress","ShakeGame"]
        GlobalVar.sharedHelper.current_score = 0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func play(_ sender: Any) {
        let x = Int(arc4random_uniform(UInt32(GlobalVar.sharedHelper.played_level.count)))
        print (x)
        let segueName = GlobalVar.sharedHelper.played_level[x]
        GlobalVar.sharedHelper.played_level.remove(at: x)
        performSegue(withIdentifier: segueName, sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
