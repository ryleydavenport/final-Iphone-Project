//
//  GlobalVar.swift
//  Group14
//
//  Created by Taelor Mcmillan on 2018-04-02.
//  Copyright © 2018 Taelor Mcmillan. All rights reserved.
//

import UIKit

class GlobalVar {
    static let sharedHelper = GlobalVar ()
    var current_score = 0
    var played_level: [String] = []
    
    
    
    

}
