//
//  User.swift
//  group14_finalProject
//
//  Created by Ryley Davenport on 2018-03-22.
//  Copyright © 2018 Ryley Davenport and Taelor Mcmillan. All rights reserved.
//

import Foundation
import UIKit
import os
class User: NSObject,NSCoding {
    let  userImage: UIImage?
    let  userName:String
    var  highScore:String
    
    init?(userimage: UIImage?, userName: String, highScore: String){
        guard !userName.isEmpty else {
            return nil }
        guard !highScore.isEmpty else {
            return nil }
        self.userImage = userimage
        self.userName = userName
        self.highScore = highScore
    } //init?
    func encode(with aCoder: NSCoder) {
        aCoder.encode(userImage, forKey: PropertyKey.userImage)
        aCoder.encode(userName, forKey: PropertyKey.userName)
        aCoder.encode(highScore, forKey: PropertyKey.highScore)
    } //encode
    required convenience init?(coder aDecoder: NSCoder) {
        
        guard let userName = aDecoder.decodeObject(forKey: PropertyKey.userName) as? String
            else {
                os_log("Unable to decode the user name for User object.", log: OSLog.default,type: .debug)
                // The question is required. If we cannot decode a question string, the initializer should
                
                return nil }
        // Because image is an optional property of Card, just use conditional cast.
        let userImage = aDecoder.decodeObject(forKey: PropertyKey.userImage) as? UIImage
        let highScore = aDecoder.decodeObject(forKey: PropertyKey.highScore)
        // Must call designated initializer.
        self.init(userimage: userImage, userName: userName, highScore: highScore as! String)
    } // decode
}// Card
struct PropertyKey {
    static let userName = "userName"
    static let userImage = "userImage"
    static let highScore = "highScore"
}


