//
//  UserArray.swift
//  group14_finalProject
//
//  Created by Ryley Davenport on 2018-03-22.
//  Copyright © 2018 Ryley Davenport and Taelor Mcmillan. All rights reserved.
//

import UIKit

class UserArray: NSObject, NSCoding {
    var users = [User]()
    var current : Int = 0 // index to the current card
    var time: String?
    let userKey = "userKey"
    let indexKey = "indexKey"
    let timeKey = "timeKey"
    // MARK: - NSCoding methods
    override init(){
        super.init()
        initUser() // initialize the deck
    }
    required convenience init?(coder decoder: NSCoder) {
        self.init()
        users = (decoder.decodeObject(forKey: userKey) as? [User])!
        current = (decoder.decodeInteger(forKey: indexKey))
        time = (decoder.decodeObject(forKey: timeKey) as? String)
       
    }
    func encode(with acoder: NSCoder) {
        acoder.encode(users, forKey: userKey)
        acoder.encode(current, forKey: indexKey)
        acoder.encode(time, forKey: timeKey)
        
        
    } // You will need to implement other helper methods such as initDeck
    func initUser(){
        let user1 = User(userimage: #imageLiteral(resourceName: "ryley"), userName: "ryley.davenport", highScore: "0")
        users.append(user1!)
    }

}
