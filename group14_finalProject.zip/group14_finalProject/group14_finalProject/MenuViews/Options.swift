//
//  Options.swift
//  group14_finalProject
//
//  Created by Ryley Davenport on 2018-03-24.
//  Copyright © 2018 Ryley Davenport and Taelor Mcmillan. All rights reserved.
//

import UIKit
import SpriteKit
class Options: SKScene {
    override func didMove(to view: SKView) {
        
        let back = SKLabelNode(fontNamed: "Impact")
        back.position = CGPoint(x: size.width/2 - 375, y: size.height - 200)
        back.fontSize = 100
        back.text = "Back"
        back.name = "backLabel"
        addChild(back)
        
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: self)
        let touchedNode = self.atPoint(touchLocation)
        //checks to seee if any of the labels are touched
        if(touchedNode.name == "backLabel"){
            let newScene = mainMenu(size: size)
            newScene.scaleMode = scaleMode
            
            let doorsClose = SKTransition.crossFade(withDuration: 3.0)
            view?.presentScene(newScene, transition: doorsClose)
            
        }
        
    }
}
