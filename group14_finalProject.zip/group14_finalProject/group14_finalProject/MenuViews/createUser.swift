//
//  createUser.swift
//  group14_finalProject
//
//  Created by Taelor Mcmillan on 2018-03-25.
//  Copyright © 2018 Ryley Davenport and Taelor Mcmillan. All rights reserved.
//

import UIKit
import SpriteKit

class createUser: SKScene {
    
    var textField: UITextField!
    var selectImage: UIImageView!
    
    override func didMove(to view: SKView) {

        let back = SKLabelNode(fontNamed: "Impact")
        back.position = CGPoint(x: size.width/2 - 375, y: size.height - 200)
        back.fontSize = 100
        back.text = "Back"
        back.name = "backLabel"
        addChild(back)
        

        
        let continueLabel = SKLabelNode(fontNamed: "Impact")
        continueLabel.position = CGPoint(x: size.width/2, y: size.height - size.height + 100)
        continueLabel.text = "Continue"
        continueLabel.name = "continueLabel"
        continueLabel.fontSize = 100
        addChild(continueLabel)
        
        let userName = SKLabelNode(fontNamed: "Impact")
        userName.position = CGPoint(x: size.width/2 , y: size.height/2 + 300)
        userName.fontSize = 100
        userName.text = "Enter Name: "
        userName.name = "userName"
        addChild(userName)
        
        
        textField = UITextField(frame: CGRect(x: size.width / 20 ,y: size.height/8 ,width:size.width / 6,height:size.height / 40))
        textField.backgroundColor = UIColor.white
        self.view?.addSubview(textField)
        
        let userImage = SKLabelNode(fontNamed: "Impact")
        userImage.position = CGPoint(x: size.width/2 , y: size.height/2 - 50)
        userImage.fontSize = 100
        userImage.text = "Select Profile Picture: "
        userImage.name = "userImage"
        addChild(userImage)
        
        let selectLabel = SKLabelNode(fontNamed: "Impact")
        selectLabel.position = CGPoint(x: size.width/2 , y: size.height/2 - 200)
        selectLabel.fontSize = 100
        selectLabel.text = "Select Image "
        selectLabel.name = "selectLabel"
        selectLabel.fontColor = UIColor.blue
        addChild(selectLabel)
        

        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: self)
        let touchedNode = self.atPoint(touchLocation)
        //checks to seee if any of the labels are touched
        if(touchedNode.name == "backLabel"){
            let newScene = selectOrCreate(size: size)
            newScene.scaleMode = scaleMode
            textField.removeFromSuperview()
            let doorsClose = SKTransition.crossFade(withDuration: 0)
            view?.presentScene(newScene, transition: doorsClose)
            
        }
        else if(touchedNode.name == "continueLabel"){
            if (textField.hasText){
                SharingUserArray.sharedUser.userArray?.users.append(User(userimage: UIImage(named: "questionMark"), userName: textField.text!, highScore: "0")!)
                let newScene = mainMenu(size: size)
                newScene.scaleMode = scaleMode
                textField.removeFromSuperview()
                let doorsClose = SKTransition.crossFade(withDuration: 0)
                view?.presentScene(newScene, transition: doorsClose)
            }
            else{
                let newScene = selectOrCreate(size: size)
                newScene.scaleMode = scaleMode
                textField.removeFromSuperview()
                let doorsClose = SKTransition.crossFade(withDuration: 0)
                view?.presentScene(newScene, transition: doorsClose)
            }
            
        }
        else if (touchedNode.name == "selectLabel" ){

        }
        
    }
}
