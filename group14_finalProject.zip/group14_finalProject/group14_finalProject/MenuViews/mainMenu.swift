//
//  mainMenu.swift
//  group14_finalProject
//
//  Created by Ryley Davenport on 2018-03-24.
//  Copyright © 2018 Ryley Davenport and Taelor Mcmillan. All rights reserved.
//

import UIKit
import SpriteKit
class mainMenu: SKScene {
    override func didMove(to view: SKView) {
        
        let playLabel = SKLabelNode(fontNamed: "Impact")
        playLabel.position = CGPoint(x: size.width/2, y: size.height/2 + 200)
        playLabel.fontSize = 100
        playLabel.text = "Play"
        playLabel.name = "playLabel"
        addChild(playLabel)
        
        let optionsLabel = SKLabelNode(fontNamed: "Impact")
        optionsLabel.position = CGPoint(x: size.width/2, y: size.height/2 + 100)
        optionsLabel.text = "Options"
        optionsLabel.name = "optionsLabel"
        optionsLabel.fontSize = 100
        addChild(optionsLabel)
        
        let instructionsLabel = SKLabelNode(fontNamed: "Impact")
        instructionsLabel.position = CGPoint(x: size.width/2, y: size.height/2)
        instructionsLabel.fontColor = UIColor.blue
        instructionsLabel.text = "Instructions"
        instructionsLabel.name = "insctructionsLabel"
        instructionsLabel.fontSize = 100
        addChild(instructionsLabel)
        
       
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: self)
        let touchedNode = self.atPoint(touchLocation)
        //checks to seee if any of the labels are touched
        if(touchedNode.name == "playLabel"){
            let newScene = GameScene(size: size)
            newScene.scaleMode = scaleMode
            
            let doorsClose = SKTransition.crossFade(withDuration: 3.0)
            view?.presentScene(newScene, transition: doorsClose)
            
        }
        else if(touchedNode.name == "insctructionsLabel"){
            let newScene = Instructions(size: size)
            newScene.scaleMode = scaleMode
            
            let doorsClose = SKTransition.doorway(withDuration: 3.0)
            view?.presentScene(newScene, transition: doorsClose)
        }
        else if(touchedNode.name == "optionsLabel"){
            let newScene = Options(size: size)
            newScene.scaleMode = scaleMode
            
            let doorsClose = SKTransition.doorway(withDuration: 3.0)
            view?.presentScene(newScene, transition: doorsClose)
        }
        
    }
}

