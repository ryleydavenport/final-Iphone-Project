//
//  selectOrCreate.swift
//  group14_finalProject
//
//  Created by Ryley Davenport on 2018-03-24.
//  Copyright © 2018 Ryley Davenport and Taelor Mcmillan. All rights reserved.
//

import UIKit
import SpriteKit
class selectOrCreate: SKScene {
    override func didMove(to view: SKView) {
        
        _ = SharingUserArray()
        SharingUserArray.sharedUser.loadUsers()
        
        let selectUser = SKLabelNode(fontNamed: "Impact")
        selectUser.position = CGPoint(x: size.width/2, y: size.height/2 + 100)
        selectUser.fontSize = 100
        selectUser.text = "Select User"
        selectUser.name = "selectLabel"
        addChild(selectUser)
        
        let creatUser = SKLabelNode(fontNamed: "Impact")
        creatUser.position = CGPoint(x: size.width/2, y: size.height/2 - 100)
        creatUser.fontSize = 100
        creatUser.text = "Create User"
        creatUser.name = "createLabel"
        addChild(creatUser)
        
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: self)
        let touchedNode = self.atPoint(touchLocation)
        //checks to seee if any of the labels are touched
        if(touchedNode.name == "selectLabel"){
            let newScene = selectUser(size: size)
            newScene.scaleMode = scaleMode
            
            let doorsClose = SKTransition.crossFade(withDuration: 0)
            view?.presentScene(newScene, transition: doorsClose)
            
        }
        else if(touchedNode.name == "createLabel"){
            let newScene = createUser(size: size)
            newScene.scaleMode = scaleMode
            
            let doorsClose = SKTransition.crossFade(withDuration: 0)
            view?.presentScene(newScene, transition: doorsClose)
            
        }
        
    }
}
