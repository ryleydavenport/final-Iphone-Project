//
//  selectUser.swift
//  group14_finalProject
//
//  Created by Ryley Davenport on 2018-03-24.
//  Copyright © 2018 Ryley Davenport and Taelor Mcmillan. All rights reserved.
//

import UIKit
import SpriteKit
var selected = false
var row = 0

class GameRoomTableView: UITableView,UITableViewDelegate,UITableViewDataSource {
    
    
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    // MARK: - Table view data source
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (SharingUserArray.sharedUser.userArray?.users.count)!
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        cell.textLabel?.text = SharingUserArray.sharedUser.userArray?.users[indexPath.row].userName
        cell.imageView?.image = SharingUserArray.sharedUser.userArray?.users[indexPath.row].userImage
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Users"
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        SharingUserArray.sharedUser.userArray?.current = indexPath.row
        print("You selected cell #\(indexPath.row)!")
    }
}
class selectUser: SKScene {
    let tableView = GameRoomTableView()
    let continueLabel = SKLabelNode(fontNamed: "Impact")
    override func didMove(to view: SKView) {
        _ = SharingUserArray()
        SharingUserArray.sharedUser.loadUsers()
    
        continueLabel.position = CGPoint(x: size.width/2, y: size.height - size.height + 100)
        continueLabel.text = "Continue"
        continueLabel.name = "continueLabel"
        continueLabel.fontSize = 100
        addChild(continueLabel)

        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.frame=CGRect(x: size.width / 20 ,y: size.height/30 ,width:size.width / 6,height:size.height / 4)
        self.scene?.view?.addSubview(tableView)
        tableView.reloadData()
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: self)
        let touchedNode = self.atPoint(touchLocation)
        //checks to seee if any of the labels are touched
        if(SharingUserArray.sharedUser.userArray?.current != 99 && touchedNode.name == "continueLabel"){
            tableView.isHidden = true
            let newScene = mainMenu(size: size)
            newScene.scaleMode = scaleMode
            
            let doorsClose = SKTransition.crossFade(withDuration: 3.0)
            view?.presentScene(newScene, transition: doorsClose)
            
        }
        
    }
   
}
